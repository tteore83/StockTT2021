<?php
//Le silence est d'or
?>